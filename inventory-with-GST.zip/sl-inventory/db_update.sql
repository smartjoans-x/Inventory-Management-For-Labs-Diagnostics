/* ============================================================================
   SL DIAGNOSTICS - INVENTORY : DATABASE UPDATE  (single file)
   ----------------------------------------------------------------------------
   Run this on an EXISTING database to bring it up to the current version.
   A brand new install does not need it - database.sql already has everything.

   It replaces the old upgrade_v3 / v4 / v5 / v6 files. Everything it adds:

     purchase orders   receive_date, invoice_no, receive_notes
                       is_direct            (direct GRN, no order raised)
                       status + 'Partial'   (part received, still open)
                       sub_total, gst_total, received_sub, received_gst
     po_items          gst_percent, gst_amount, line_total
     po_receipts       NEW TABLE - what was actually received, per lot,
                       receipt_no / posted_at / posted_by for part deliveries
     items             department_id, equipment_id, default_supplier_id,
                       default_gst_percent
     item_batches      gst_percent
     stock_out         department_id, voucher_no, received_by
     departments       NEW TABLE
     equipments        NEW TABLE
     stock_month_summary NEW TABLE - the monthly budget sheet
     v_item_stock      rebuilt with the new columns

   *** SAFE TO RUN AGAIN ***  Every step checks itself first, so a second run
   prints "already there" instead of failing with #1060 / #1061 / #1050.
   Nothing is deleted and no existing data is overwritten.
   ============================================================================ */

USE `sl_inventory`;
SET @db := DATABASE();
SELECT '--- starting update ---' AS progress;


/* =========================== NEW TABLES =========================== */
CREATE TABLE IF NOT EXISTS `departments` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `dept_name`  VARCHAR(80)  NOT NULL,
  `is_active`  TINYINT(1)   NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_dept_name` (`dept_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `equipments` (
  `id`             INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `equipment_name` VARCHAR(100) NOT NULL,
  `department_id`  INT UNSIGNED DEFAULT NULL,
  `is_active`      TINYINT(1)   NOT NULL DEFAULT 1,
  `created_at`     TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_equipment` (`equipment_name`, `department_id`),
  KEY `idx_equip_dept` (`department_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `po_receipts` (
  `id`           INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `po_id`        INT UNSIGNED  NOT NULL,
  `po_item_id`   INT UNSIGNED  NOT NULL,
  `item_id`      INT UNSIGNED  NOT NULL,
  `receipt_no`   INT UNSIGNED  NOT NULL DEFAULT 1,
  `lot_number`   VARCHAR(80)   DEFAULT NULL,
  `expiry_date`  DATE          DEFAULT NULL,
  `quantity`     DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `unit_rate`    DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `total_amount` DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `gst_percent`  DECIMAL(5,2)  NOT NULL DEFAULT 0.00,
  `gst_amount`   DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `line_total`   DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `batch_id`     INT UNSIGNED  DEFAULT NULL,
  `posted_at`    DATETIME      DEFAULT NULL,
  `posted_by`    INT UNSIGNED  DEFAULT NULL,
  `created_at`   TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_rcpt_po`    (`po_id`),
  KEY `idx_rcpt_line`  (`po_item_id`),
  KEY `idx_rcpt_item`  (`item_id`),
  KEY `idx_rcpt_batch` (`batch_id`),
  KEY `idx_rcpt_user`  (`posted_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `stock_month_summary` (
  `id`         INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `month_key`  CHAR(7)       NOT NULL,
  `reqd_month` CHAR(7)       DEFAULT NULL,
  `item_id`    INT UNSIGNED  NOT NULL,
  `op_qty`     DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `op_value`   DECIMAL(16,2) NOT NULL DEFAULT 0.00,
  `pur_qty`    DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `pur_value`  DECIMAL(16,2) NOT NULL DEFAULT 0.00,
  `iss_qty`    DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `iss_value`  DECIMAL(16,2) NOT NULL DEFAULT 0.00,
  `cl_qty`     DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `cl_value`   DECIMAL(16,2) NOT NULL DEFAULT 0.00,
  `reqd_qty`   DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `reqd_rate`  DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `reqd_value` DECIMAL(16,2) NOT NULL DEFAULT 0.00,
  `source`     ENUM('Imported','System') NOT NULL DEFAULT 'System',
  `note`       VARCHAR(190)  DEFAULT NULL,
  `updated_by` INT UNSIGNED  DEFAULT NULL,
  `updated_at` TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_month_item` (`month_key`, `item_id`),
  KEY `idx_sms_item`  (`item_id`),
  KEY `idx_sms_month` (`month_key`),
  KEY `idx_sms_user`  (`updated_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
SELECT '1. tables checked' AS progress;

/* ============================= COLUMNS ============================= */

SET @n := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA=@db AND TABLE_NAME='purchase_orders' AND COLUMN_NAME='received_total');
SET @s := IF(@n > 0, 'SELECT ''purchase_orders.received_total : already there'' AS step',
  'ALTER TABLE `purchase_orders` ADD COLUMN `received_total` DECIMAL(14,2) NOT NULL DEFAULT 0.00 AFTER `grand_total`');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;

SET @n := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA=@db AND TABLE_NAME='purchase_orders' AND COLUMN_NAME='receive_date');
SET @s := IF(@n > 0, 'SELECT ''purchase_orders.receive_date : already there'' AS step',
  'ALTER TABLE `purchase_orders` ADD COLUMN `receive_date` DATE DEFAULT NULL AFTER `received_total`');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;

SET @n := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA=@db AND TABLE_NAME='purchase_orders' AND COLUMN_NAME='invoice_no');
SET @s := IF(@n > 0, 'SELECT ''purchase_orders.invoice_no : already there'' AS step',
  'ALTER TABLE `purchase_orders` ADD COLUMN `invoice_no` VARCHAR(60) DEFAULT NULL AFTER `receive_date`');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;

SET @n := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA=@db AND TABLE_NAME='purchase_orders' AND COLUMN_NAME='receive_notes');
SET @s := IF(@n > 0, 'SELECT ''purchase_orders.receive_notes : already there'' AS step',
  'ALTER TABLE `purchase_orders` ADD COLUMN `receive_notes` TEXT NULL AFTER `invoice_no`');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;

SET @n := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA=@db AND TABLE_NAME='purchase_orders' AND COLUMN_NAME='is_direct');
SET @s := IF(@n > 0, 'SELECT ''purchase_orders.is_direct : already there'' AS step',
  'ALTER TABLE `purchase_orders` ADD COLUMN `is_direct` TINYINT(1) NOT NULL DEFAULT 0 AFTER `status`');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;

SET @n := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA=@db AND TABLE_NAME='purchase_orders' AND COLUMN_NAME='sub_total');
SET @s := IF(@n > 0, 'SELECT ''purchase_orders.sub_total : already there'' AS step',
  'ALTER TABLE `purchase_orders` ADD COLUMN `sub_total` DECIMAL(14,2) NOT NULL DEFAULT 0.00 AFTER `is_direct`');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;

SET @n := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA=@db AND TABLE_NAME='purchase_orders' AND COLUMN_NAME='gst_total');
SET @s := IF(@n > 0, 'SELECT ''purchase_orders.gst_total : already there'' AS step',
  'ALTER TABLE `purchase_orders` ADD COLUMN `gst_total` DECIMAL(14,2) NOT NULL DEFAULT 0.00 AFTER `sub_total`');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;

SET @n := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA=@db AND TABLE_NAME='purchase_orders' AND COLUMN_NAME='received_sub');
SET @s := IF(@n > 0, 'SELECT ''purchase_orders.received_sub : already there'' AS step',
  'ALTER TABLE `purchase_orders` ADD COLUMN `received_sub` DECIMAL(14,2) NOT NULL DEFAULT 0.00 AFTER `received_total`');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;

SET @n := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA=@db AND TABLE_NAME='purchase_orders' AND COLUMN_NAME='received_gst');
SET @s := IF(@n > 0, 'SELECT ''purchase_orders.received_gst : already there'' AS step',
  'ALTER TABLE `purchase_orders` ADD COLUMN `received_gst` DECIMAL(14,2) NOT NULL DEFAULT 0.00 AFTER `received_sub`');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;

SET @n := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA=@db AND TABLE_NAME='po_items' AND COLUMN_NAME='gst_percent');
SET @s := IF(@n > 0, 'SELECT ''po_items.gst_percent : already there'' AS step',
  'ALTER TABLE `po_items` ADD COLUMN `gst_percent` DECIMAL(5,2) NOT NULL DEFAULT 0.00 AFTER `total_amount`');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;

SET @n := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA=@db AND TABLE_NAME='po_items' AND COLUMN_NAME='gst_amount');
SET @s := IF(@n > 0, 'SELECT ''po_items.gst_amount : already there'' AS step',
  'ALTER TABLE `po_items` ADD COLUMN `gst_amount` DECIMAL(14,2) NOT NULL DEFAULT 0.00 AFTER `gst_percent`');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;

SET @n := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA=@db AND TABLE_NAME='po_items' AND COLUMN_NAME='line_total');
SET @s := IF(@n > 0, 'SELECT ''po_items.line_total : already there'' AS step',
  'ALTER TABLE `po_items` ADD COLUMN `line_total` DECIMAL(14,2) NOT NULL DEFAULT 0.00 AFTER `gst_amount`');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;

SET @n := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA=@db AND TABLE_NAME='items' AND COLUMN_NAME='default_gst_percent');
SET @s := IF(@n > 0, 'SELECT ''items.default_gst_percent : already there'' AS step',
  'ALTER TABLE `items` ADD COLUMN `default_gst_percent` DECIMAL(5,2) NOT NULL DEFAULT 0.00 AFTER `min_stock_alert`');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;

SET @n := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA=@db AND TABLE_NAME='items' AND COLUMN_NAME='department_id');
SET @s := IF(@n > 0, 'SELECT ''items.department_id : already there'' AS step',
  'ALTER TABLE `items` ADD COLUMN `department_id` INT UNSIGNED DEFAULT NULL AFTER `default_gst_percent`');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;

SET @n := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA=@db AND TABLE_NAME='items' AND COLUMN_NAME='equipment_id');
SET @s := IF(@n > 0, 'SELECT ''items.equipment_id : already there'' AS step',
  'ALTER TABLE `items` ADD COLUMN `equipment_id` INT UNSIGNED DEFAULT NULL AFTER `department_id`');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;

SET @n := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA=@db AND TABLE_NAME='items' AND COLUMN_NAME='default_supplier_id');
SET @s := IF(@n > 0, 'SELECT ''items.default_supplier_id : already there'' AS step',
  'ALTER TABLE `items` ADD COLUMN `default_supplier_id` INT UNSIGNED DEFAULT NULL AFTER `equipment_id`');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;

SET @n := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA=@db AND TABLE_NAME='item_batches' AND COLUMN_NAME='gst_percent');
SET @s := IF(@n > 0, 'SELECT ''item_batches.gst_percent : already there'' AS step',
  'ALTER TABLE `item_batches` ADD COLUMN `gst_percent` DECIMAL(5,2) NOT NULL DEFAULT 0.00 AFTER `unit_price`');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;

SET @n := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA=@db AND TABLE_NAME='stock_out' AND COLUMN_NAME='department_id');
SET @s := IF(@n > 0, 'SELECT ''stock_out.department_id : already there'' AS step',
  'ALTER TABLE `stock_out` ADD COLUMN `department_id` INT UNSIGNED DEFAULT NULL AFTER `out_date`');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;

SET @n := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA=@db AND TABLE_NAME='stock_out' AND COLUMN_NAME='voucher_no');
SET @s := IF(@n > 0, 'SELECT ''stock_out.voucher_no : already there'' AS step',
  'ALTER TABLE `stock_out` ADD COLUMN `voucher_no` VARCHAR(40) DEFAULT NULL AFTER `id`');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;

SET @n := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA=@db AND TABLE_NAME='stock_out' AND COLUMN_NAME='received_by');
SET @s := IF(@n > 0, 'SELECT ''stock_out.received_by : already there'' AS step',
  'ALTER TABLE `stock_out` ADD COLUMN `received_by` VARCHAR(120) DEFAULT NULL AFTER `issued_to`');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;
SELECT '2. columns checked' AS progress;

/* ---------------------- status: add 'Partial' --------------------------- */
SET @n := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA=@db AND TABLE_NAME='purchase_orders'
             AND COLUMN_NAME='status' AND COLUMN_TYPE LIKE '%Partial%');
SET @s := IF(@n > 0, 'SELECT ''status : Partial already allowed'' AS step',
  'ALTER TABLE `purchase_orders` MODIFY COLUMN `status`
     ENUM(''Draft'',''Partial'',''Final'') NOT NULL DEFAULT ''Draft''');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;
SELECT '3. status enum checked' AS progress;

/* ============================= INDEXES ============================= */

SET @n := (SELECT COUNT(*) FROM information_schema.STATISTICS
           WHERE TABLE_SCHEMA=@db AND TABLE_NAME='purchase_orders' AND INDEX_NAME='idx_po_direct');
SET @s := IF(@n > 0, 'SELECT ''purchase_orders.idx_po_direct : already there'' AS step',
  'ALTER TABLE `purchase_orders` ADD KEY `idx_po_direct` (`is_direct`)');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;

SET @n := (SELECT COUNT(*) FROM information_schema.STATISTICS
           WHERE TABLE_SCHEMA=@db AND TABLE_NAME='items' AND INDEX_NAME='idx_item_dept');
SET @s := IF(@n > 0, 'SELECT ''items.idx_item_dept : already there'' AS step',
  'ALTER TABLE `items` ADD KEY `idx_item_dept` (`department_id`)');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;

SET @n := (SELECT COUNT(*) FROM information_schema.STATISTICS
           WHERE TABLE_SCHEMA=@db AND TABLE_NAME='items' AND INDEX_NAME='idx_item_equip');
SET @s := IF(@n > 0, 'SELECT ''items.idx_item_equip : already there'' AS step',
  'ALTER TABLE `items` ADD KEY `idx_item_equip` (`equipment_id`)');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;

SET @n := (SELECT COUNT(*) FROM information_schema.STATISTICS
           WHERE TABLE_SCHEMA=@db AND TABLE_NAME='items' AND INDEX_NAME='idx_item_sup');
SET @s := IF(@n > 0, 'SELECT ''items.idx_item_sup : already there'' AS step',
  'ALTER TABLE `items` ADD KEY `idx_item_sup` (`default_supplier_id`)');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;

SET @n := (SELECT COUNT(*) FROM information_schema.STATISTICS
           WHERE TABLE_SCHEMA=@db AND TABLE_NAME='stock_out' AND INDEX_NAME='idx_out_dept');
SET @s := IF(@n > 0, 'SELECT ''stock_out.idx_out_dept : already there'' AS step',
  'ALTER TABLE `stock_out` ADD KEY `idx_out_dept` (`department_id`)');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;

SET @n := (SELECT COUNT(*) FROM information_schema.STATISTICS
           WHERE TABLE_SCHEMA=@db AND TABLE_NAME='stock_out' AND INDEX_NAME='idx_out_voucher');
SET @s := IF(@n > 0, 'SELECT ''stock_out.idx_out_voucher : already there'' AS step',
  'ALTER TABLE `stock_out` ADD KEY `idx_out_voucher` (`voucher_no`)');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;
SELECT '4. indexes checked' AS progress;

/* =========================== FOREIGN KEYS ========================== */

SET @n := (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
           WHERE TABLE_SCHEMA=@db AND TABLE_NAME='equipments' AND CONSTRAINT_NAME='fk_equip_dept');
SET @s := IF(@n > 0, 'SELECT ''equipments.fk_equip_dept : already there'' AS step',
  'ALTER TABLE `equipments` ADD CONSTRAINT `fk_equip_dept` FOREIGN KEY (`department_id`)
     REFERENCES `departments` (`id`) ON DELETE SET NULL ON UPDATE CASCADE');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;

SET @n := (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
           WHERE TABLE_SCHEMA=@db AND TABLE_NAME='items' AND CONSTRAINT_NAME='fk_item_dept');
SET @s := IF(@n > 0, 'SELECT ''items.fk_item_dept : already there'' AS step',
  'ALTER TABLE `items` ADD CONSTRAINT `fk_item_dept` FOREIGN KEY (`department_id`)
     REFERENCES `departments` (`id`) ON DELETE SET NULL ON UPDATE CASCADE');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;

SET @n := (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
           WHERE TABLE_SCHEMA=@db AND TABLE_NAME='items' AND CONSTRAINT_NAME='fk_item_equip');
SET @s := IF(@n > 0, 'SELECT ''items.fk_item_equip : already there'' AS step',
  'ALTER TABLE `items` ADD CONSTRAINT `fk_item_equip` FOREIGN KEY (`equipment_id`)
     REFERENCES `equipments` (`id`) ON DELETE SET NULL ON UPDATE CASCADE');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;

SET @n := (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
           WHERE TABLE_SCHEMA=@db AND TABLE_NAME='items' AND CONSTRAINT_NAME='fk_item_supplier');
SET @s := IF(@n > 0, 'SELECT ''items.fk_item_supplier : already there'' AS step',
  'ALTER TABLE `items` ADD CONSTRAINT `fk_item_supplier` FOREIGN KEY (`default_supplier_id`)
     REFERENCES `suppliers` (`id`) ON DELETE SET NULL ON UPDATE CASCADE');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;

SET @n := (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
           WHERE TABLE_SCHEMA=@db AND TABLE_NAME='stock_out' AND CONSTRAINT_NAME='fk_out_dept');
SET @s := IF(@n > 0, 'SELECT ''stock_out.fk_out_dept : already there'' AS step',
  'ALTER TABLE `stock_out` ADD CONSTRAINT `fk_out_dept` FOREIGN KEY (`department_id`)
     REFERENCES `departments` (`id`) ON DELETE SET NULL ON UPDATE CASCADE');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;

SET @n := (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
           WHERE TABLE_SCHEMA=@db AND TABLE_NAME='po_receipts' AND CONSTRAINT_NAME='fk_rcpt_po');
SET @s := IF(@n > 0, 'SELECT ''po_receipts.fk_rcpt_po : already there'' AS step',
  'ALTER TABLE `po_receipts` ADD CONSTRAINT `fk_rcpt_po` FOREIGN KEY (`po_id`)
     REFERENCES `purchase_orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;

SET @n := (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
           WHERE TABLE_SCHEMA=@db AND TABLE_NAME='po_receipts' AND CONSTRAINT_NAME='fk_rcpt_poitem');
SET @s := IF(@n > 0, 'SELECT ''po_receipts.fk_rcpt_poitem : already there'' AS step',
  'ALTER TABLE `po_receipts` ADD CONSTRAINT `fk_rcpt_poitem` FOREIGN KEY (`po_item_id`)
     REFERENCES `po_items` (`id`) ON DELETE CASCADE ON UPDATE CASCADE');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;

SET @n := (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
           WHERE TABLE_SCHEMA=@db AND TABLE_NAME='po_receipts' AND CONSTRAINT_NAME='fk_rcpt_item');
SET @s := IF(@n > 0, 'SELECT ''po_receipts.fk_rcpt_item : already there'' AS step',
  'ALTER TABLE `po_receipts` ADD CONSTRAINT `fk_rcpt_item` FOREIGN KEY (`item_id`)
     REFERENCES `items` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;

SET @n := (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
           WHERE TABLE_SCHEMA=@db AND TABLE_NAME='po_receipts' AND CONSTRAINT_NAME='fk_rcpt_batch');
SET @s := IF(@n > 0, 'SELECT ''po_receipts.fk_rcpt_batch : already there'' AS step',
  'ALTER TABLE `po_receipts` ADD CONSTRAINT `fk_rcpt_batch` FOREIGN KEY (`batch_id`)
     REFERENCES `item_batches` (`id`) ON DELETE SET NULL ON UPDATE CASCADE');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;

SET @n := (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
           WHERE TABLE_SCHEMA=@db AND TABLE_NAME='po_receipts' AND CONSTRAINT_NAME='fk_rcpt_user');
SET @s := IF(@n > 0, 'SELECT ''po_receipts.fk_rcpt_user : already there'' AS step',
  'ALTER TABLE `po_receipts` ADD CONSTRAINT `fk_rcpt_user` FOREIGN KEY (`posted_by`)
     REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;

SET @n := (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
           WHERE TABLE_SCHEMA=@db AND TABLE_NAME='stock_month_summary' AND CONSTRAINT_NAME='fk_sms_item');
SET @s := IF(@n > 0, 'SELECT ''stock_month_summary.fk_sms_item : already there'' AS step',
  'ALTER TABLE `stock_month_summary` ADD CONSTRAINT `fk_sms_item` FOREIGN KEY (`item_id`)
     REFERENCES `items` (`id`) ON DELETE CASCADE ON UPDATE CASCADE');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;

SET @n := (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
           WHERE TABLE_SCHEMA=@db AND TABLE_NAME='stock_month_summary' AND CONSTRAINT_NAME='fk_sms_user');
SET @s := IF(@n > 0, 'SELECT ''stock_month_summary.fk_sms_user : already there'' AS step',
  'ALTER TABLE `stock_month_summary` ADD CONSTRAINT `fk_sms_user` FOREIGN KEY (`updated_by`)
     REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;
SELECT '5. foreign keys checked' AS progress;

/* ============================== VIEW =============================== */
DROP VIEW IF EXISTS `v_item_stock`;
CREATE VIEW `v_item_stock` AS
SELECT
    i.id                AS item_id,
    i.item_code,
    i.item_name,
    i.category,
    i.unit,
    i.has_lot,
    i.min_stock_alert,
    i.default_gst_percent,
    i.is_active,
    i.department_id,
    i.equipment_id,
    i.default_supplier_id,
    d.dept_name,
    e.equipment_name,
    sp.supplier_name    AS default_supplier_name,
    COALESCE(SUM(b.quantity_available), 0)                  AS total_qty,
    COALESCE(SUM(b.quantity_available * b.unit_price), 0)   AS stock_value,
    COUNT(b.id)                                             AS batch_count,
    MIN(b.expiry_date)                                      AS next_expiry,
    MAX(b.unit_price)                                       AS max_rate,
    MIN(b.unit_price)                                       AS min_rate
FROM `items` i
LEFT JOIN `item_batches` b
       ON b.item_id = i.id AND b.quantity_available > 0
LEFT JOIN `departments` d  ON d.id  = i.department_id
LEFT JOIN `equipments`  e  ON e.id  = i.equipment_id
LEFT JOIN `suppliers`   sp ON sp.id = i.default_supplier_id
GROUP BY i.id, d.dept_name, e.equipment_name, sp.supplier_name;
SELECT '6. view rebuilt' AS progress;

/* ============================ BACK FILL =============================
   Rows written before GST existed carry 0 GST, so the taxable value is the
   whole amount. These only touch rows that have not been filled yet. */

UPDATE `po_items`   SET `line_total` = `total_amount`
 WHERE `line_total` = 0 AND `total_amount` <> 0;
UPDATE `po_receipts` SET `line_total` = `total_amount`
 WHERE `line_total` = 0 AND `total_amount` <> 0;
UPDATE `purchase_orders` SET `sub_total` = `grand_total`
 WHERE `sub_total` = 0 AND `grand_total` <> 0;
UPDATE `purchase_orders` SET `received_sub` = `received_total`
 WHERE `received_sub` = 0 AND `received_total` <> 0;

/* older issue rows were entered one at a time: give each its own voucher */
UPDATE `stock_out` SET `voucher_no` = CONCAT('ISS/LEGACY/', LPAD(`id`, 4, '0'))
 WHERE `voucher_no` IS NULL;

/* match free text departments on old issues to the department list */
UPDATE `stock_out` o
  JOIN `departments` d ON d.dept_name = o.issued_to
   SET o.department_id = d.id
 WHERE o.department_id IS NULL;

/* purchase orders finalized under the old one-shot flow have no receipt rows:
   copy their ordered lines across so ordered vs received still reconciles */
INSERT INTO `po_receipts`
      (`po_id`, `po_item_id`, `item_id`, `receipt_no`, `lot_number`, `expiry_date`,
       `quantity`, `unit_rate`, `total_amount`, `gst_percent`, `gst_amount`, `line_total`)
SELECT pi.po_id, pi.id, pi.item_id, 1, 'GENERAL', NULL,
       pi.quantity, pi.unit_rate, pi.total_amount, 0, 0, pi.total_amount
  FROM `po_items` pi
  JOIN `purchase_orders` po ON po.id = pi.po_id
 WHERE po.status = 'Final'
   AND NOT EXISTS (SELECT 1 FROM `po_receipts` r WHERE r.po_id = pi.po_id);

UPDATE `purchase_orders` po
   SET po.received_sub   = (SELECT COALESCE(SUM(r.total_amount),0) FROM `po_receipts` r WHERE r.po_id = po.id),
       po.received_gst   = (SELECT COALESCE(SUM(r.gst_amount),0)   FROM `po_receipts` r WHERE r.po_id = po.id),
       po.received_total = (SELECT COALESCE(SUM(r.line_total),0)   FROM `po_receipts` r WHERE r.po_id = po.id),
       po.receive_date   = COALESCE(po.receive_date, po.po_date)
 WHERE po.status = 'Final';

SELECT '7. existing data back filled' AS progress;

/* ============================== CHECK ============================== */
SELECT 'departments'         AS object, COUNT(*) AS rows_ FROM `departments`
UNION ALL SELECT 'equipments',          COUNT(*) FROM `equipments`
UNION ALL SELECT 'po_receipts',         COUNT(*) FROM `po_receipts`
UNION ALL SELECT 'stock_month_summary', COUNT(*) FROM `stock_month_summary`
UNION ALL SELECT 'items',               COUNT(*) FROM `items`
UNION ALL SELECT 'stock lots',          COUNT(*) FROM `item_batches`;

SELECT '--- update complete ---' AS progress;
