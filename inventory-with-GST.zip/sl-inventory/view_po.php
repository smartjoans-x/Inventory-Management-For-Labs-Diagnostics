<?php
/* ============================================================================
   view_po.php - Purchase order / Goods Receive Note view + clean print layout
   ?id=<po id>            view
   ?id=<po id>&print=1    open the browser print dialog automatically
   ----------------------------------------------------------------------------
   Draft   : the order, with a button to receive it
   Partial : part received - what is in, what is still due
   Final   : closed. The receipt table shows, per item,
             ordered qty | received qty | not received qty | rate | GST | total
   ============================================================================ */
require_once __DIR__ . '/db.php';
require_login();

$poId = get_int('id');

/* ------------------------------- ACTIONS --------------------------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = post_str('action');
    $poId   = post_int('id');

    if ($action === 'delete') {
        $res = delete_draft_po($pdo, $poId);
        flash(h($res['message']), $res['ok'] ? 'success' : 'warning');
        redirect($res['ok'] ? 'po_list.php' : 'view_po.php?id=' . $poId);
    }
    if ($action === 'close') {
        $res = close_po($pdo, $poId, user_id());
        flash(h($res['message']), $res['ok'] ? 'success' : 'warning');
        redirect('view_po.php?id=' . $poId);
    }
}

/* --------------------------------- LOAD ---------------------------------- */
$st = $pdo->prepare('SELECT po.*, s.supplier_name, s.contact_person, s.phone, s.email, s.gst_no, s.address,
                            cu.full_name AS created_by_name, fu.full_name AS finalized_by_name
                     FROM purchase_orders po
                     JOIN suppliers s ON s.id = po.supplier_id
                     LEFT JOIN users cu ON cu.id = po.created_by
                     LEFT JOIN users fu ON fu.id = po.finalized_by
                     WHERE po.id = ?');
$st->execute([$poId]);
$po = $st->fetch();

if (!$po) {
    flash('Purchase order not found.', 'warning');
    redirect('po_list.php');
}

$lines = po_balance($pdo, $poId);

/* receipt rows grouped under their ordered line */
$st = $pdo->prepare('SELECT r.*, u.full_name AS posted_by_name
                     FROM po_receipts r
                     LEFT JOIN users u ON u.id = r.posted_by
                     WHERE r.po_id = ?
                     ORDER BY r.po_item_id, r.receipt_no, r.id');
$st->execute([$poId]);
$receipts = [];
foreach ($st->fetchAll() as $r) {
    $receipts[(int)$r['po_item_id']][] = $r;
}

$status   = (string)$po['status'];
$isDraft  = $status === 'Draft';
$isPartial= $status === 'Partial';
$isFinal  = $status === 'Final';
$isDirect = (int)($po['is_direct'] ?? 0) === 1;
$isOpen   = !$isFinal;                       // can still receive
$numLabel = $isDirect ? 'GRN No' : 'PO No';
$hasRcpt  = !empty($receipts);
$var      = po_variance($po);

$totalOrdQty = 0.0;
$totalGotQty = 0.0;
$totalDueQty = 0.0;
foreach ($lines as $l) {
    $totalOrdQty += (float)$l['ordered_qty'];
    $totalGotQty += (float)$l['received_qty'];
    $totalDueQty += (float)$l['balance_qty'];
}

/* stock lots created by this document */
$st = $pdo->prepare('SELECT b.*, i.item_name, i.unit
                     FROM item_batches b
                     JOIN items i ON i.id = b.item_id
                     WHERE b.po_id = ?
                     ORDER BY i.item_name, b.lot_number');
$st->execute([$poId]);
$batches = $st->fetchAll();

$statusCss = $isFinal ? 'badge-soft-success' : ($isPartial ? 'badge-soft-warning' : 'badge-soft-secondary');
$statusIcn = $isFinal ? 'bi-check2-circle' : ($isPartial ? 'bi-hourglass-split' : 'bi-pencil');

$page_title = ($isDirect ? 'GRN ' : 'PO ') . $po['po_number'];
$page_icon  = 'bi-file-earmark-text';
$active     = 'po_list';
require __DIR__ . '/includes/header.php';
?>

<!-- ---------------------------- ACTION BAR ---------------------------- -->
<div class="card mb-3 no-print">
  <div class="card-body d-flex flex-wrap gap-2 align-items-center">
    <span class="badge <?= $statusCss ?> fs-6">
      <i class="bi <?= $statusIcn ?>"></i> <?= h($status) ?>
    </span>
    <?php if ($isDirect): ?>
      <span class="badge badge-soft-warning fs-6"><i class="bi bi-lightning-charge"></i> Direct GRN</span>
    <?php endif; ?>

    <?php if ($isDraft): ?>
      <span class="help">Order record - live stock has <b>not</b> been updated yet.</span>
    <?php elseif ($isPartial): ?>
      <span class="help">Part received - <b><?= qty_str($totalGotQty) ?></b> of
        <b><?= qty_str($totalOrdQty) ?></b> units in, <b><?= qty_str($totalDueQty) ?></b> still due.</span>
    <?php else: ?>
      <span class="help">Received<?= $po['receive_date'] ? ' on ' . dmy($po['receive_date']) : '' ?>
        and posted to stock<?= $po['finalized_by_name'] ? ' by ' . h($po['finalized_by_name']) : '' ?>.</span>
    <?php endif; ?>
    <?php if ($po['created_by_name']): ?>
      <span class="help"><i class="bi bi-person"></i> <?= $isDirect ? 'Entered' : 'Ordered' ?> by <?= h($po['created_by_name']) ?></span>
    <?php endif; ?>

    <div class="ms-auto d-flex flex-wrap gap-2">
      <button class="btn btn-sm btn-outline-dark" onclick="window.print()">
        <i class="bi bi-printer"></i> Print
      </button>
      <?php if ($isDraft): ?>
        <a href="create_po.php?id=<?= (int)$po['id'] ?>" class="btn btn-sm btn-outline-primary">
          <i class="bi bi-pencil"></i> Edit Draft
        </a>
      <?php endif; ?>
      <?php if ($isOpen): ?>
        <a href="receive_po.php?id=<?= (int)$po['id'] ?>" class="btn btn-sm btn-teal">
          <i class="bi bi-box-arrow-in-down"></i> <?= $isPartial ? 'Receive Balance' : 'Receive (GRN)' ?>
        </a>
      <?php endif; ?>
      <?php if ($isPartial): ?>
        <form method="post" class="d-inline"
              data-confirm="Close <?= h($po['po_number']) ?> without receiving the balance?">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="close">
          <input type="hidden" name="id" value="<?= (int)$po['id'] ?>">
          <button class="btn btn-sm btn-outline-secondary"><i class="bi bi-x-circle"></i> Close</button>
        </form>
      <?php endif; ?>
      <?php if ($isDraft): ?>
        <form method="post" class="d-inline" data-confirm="Delete draft <?= h($po['po_number']) ?>?">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="delete">
          <input type="hidden" name="id" value="<?= (int)$po['id'] ?>">
          <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i> Delete</button>
        </form>
      <?php endif; ?>
      <a href="po_list.php" class="btn btn-sm btn-light"><i class="bi bi-arrow-left"></i> Back</a>
    </div>
  </div>
</div>

<?php if (!$isDraft): ?>
<!-- ------------------------ ORDERED vs RECEIVED ----------------------- -->
<div class="row g-3 mb-3 no-print">
  <div class="col-6 col-xl-3">
    <div class="stat">
      <div class="stat-label">Ordered (incl GST)</div>
      <div class="stat-value"><?= money($var['ordered']) ?></div>
      <div class="stat-sub"><?= qty_str($totalOrdQty) ?> units</div>
    </div>
  </div>
  <div class="col-6 col-xl-3">
    <div class="stat">
      <div class="stat-label">Received (incl GST)</div>
      <div class="stat-value"><?= money($var['received']) ?></div>
      <div class="stat-sub"><?= qty_str($totalGotQty) ?> units in</div>
    </div>
  </div>
  <div class="col-6 col-xl-3">
    <div class="stat">
      <div class="stat-label">Not received</div>
      <div class="stat-value <?= $totalDueQty > 0 ? 'text-warning' : '' ?>"><?= qty_str($totalDueQty) ?></div>
      <div class="stat-sub"><?= $totalDueQty > 0 ? ($isFinal ? 'closed short' : 'still to come') : 'nothing pending' ?></div>
    </div>
  </div>
  <div class="col-6 col-xl-3">
    <div class="stat">
      <div class="stat-label">Difference in value</div>
      <div class="stat-value <?= $var['diff'] > 0.005 ? 'text-danger' : ($var['diff'] < -0.005 ? 'text-warning' : '') ?>">
        <?= (abs($var['diff']) < 0.005 ? '' : ($var['diff'] > 0 ? '+ ' : '- ')) . money(abs($var['diff'])) ?>
      </div>
      <div class="stat-sub"><?= number_format($var['pct'], 1) ?>% of the order</div>
    </div>
  </div>
</div>
<?php endif; ?>

<!-- ---------------------------- PRINT SHEET --------------------------- -->
<div class="print-sheet">

  <div class="print-head d-flex justify-content-between align-items-start flex-wrap gap-3">
    <div class="d-flex align-items-center gap-3">
      <?php if (has_logo()): ?>
        <?= logo_img('po-logo') ?>
      <?php else: ?>
        <div>
          <div class="brand-font co-name"><?= h(APP_BRAND) ?></div>
          <div class="small text-muted"><?= h(APP_TAGLINE) ?></div>
        </div>
      <?php endif; ?>
      <div class="small">
        <?php if (APP_ADDRESS !== ''): ?><div><?= h(APP_ADDRESS) ?></div><?php endif; ?>
        <?php if (APP_GST !== ''): ?><div>GSTIN: <?= h(APP_GST) ?></div><?php endif; ?>
      </div>
    </div>
    <div class="text-end small">
      <div><b><?= h($numLabel) ?>:</b> <span class="mono"><?= h($po['po_number']) ?></span></div>
      <div><b><?= $isDirect ? 'Date' : 'PO Date' ?>:</b> <?= dmy($po['po_date']) ?></div>
      <div><b>Status:</b> <?= h(strtoupper($status)) ?></div>
      <?php if ($isDraft): ?>
        <div class="text-danger"><b>DRAFT - NOT YET RECEIVED</b></div>
      <?php else: ?>
        <div><b>Received:</b> <?= dmy($po['receive_date']) ?></div>
        <?php if ($po['invoice_no']): ?><div><b>Invoice:</b> <span class="mono"><?= h($po['invoice_no']) ?></span></div><?php endif; ?>
      <?php endif; ?>
    </div>
  </div>

  <div class="print-title"><?= $isDraft ? h(DOC_NAME) : h(GRN_NAME) ?></div>
  <?php if ($isDirect): ?>
    <div class="text-center small text-muted mb-3" style="margin-top:-10px">
      Direct receipt - no purchase order was raised
    </div>
  <?php elseif (!$isDraft): ?>
    <div class="text-center small text-muted mb-3" style="margin-top:-10px">
      Against purchase order <span class="mono"><?= h($po['po_number']) ?></span>
      <?= $isPartial ? ' - part delivery' : '' ?>
    </div>
  <?php endif; ?>

  <?php $hasNotes = trim((string)$po['notes']) !== '' || trim((string)$po['receive_notes']) !== ''; ?>
  <div class="row g-3 mb-3 doc-meta">
    <div class="col-12 <?= $hasNotes ? 'col-md-7' : '' ?>">
      <div class="border rounded p-2 h-100">
        <div class="small text-muted text-uppercase" style="letter-spacing:1px">Supplier</div>
        <div class="fw-bold"><?= h($po['supplier_name']) ?></div>
        <?php if ($po['address']): ?><div class="small"><?= h($po['address']) ?></div><?php endif; ?>
        <div class="small">
          <?php if ($po['contact_person']): ?><?= h($po['contact_person']) ?><?php endif; ?>
          <?php if ($po['phone']): ?> &middot; <?= h($po['phone']) ?><?php endif; ?>
          <?php if ($po['email']): ?> &middot; <?= h($po['email']) ?><?php endif; ?>
        </div>
        <?php if ($po['gst_no']): ?><div class="small">GSTIN: <span class="mono"><?= h($po['gst_no']) ?></span></div><?php endif; ?>
      </div>
    </div>
    <?php if ($hasNotes): ?>
    <div class="col-12 col-md-5">
      <div class="border rounded p-2 h-100">
        <div class="small text-muted text-uppercase" style="letter-spacing:1px">Notes / Reference</div>
        <?php if ($po['notes']): ?>
          <div class="small"><?= nl2br(h($po['notes'])) ?></div>
        <?php endif; ?>
        <?php if ($po['receive_notes']): ?>
          <div class="small mt-1"><b>Receipt:</b> <?= h($po['receive_notes']) ?></div>
        <?php endif; ?>
      </div>
    </div>
    <?php endif; ?>
  </div>

  <!-- ===================== THE MAIN TABLE ===================== -->
  <?php if ($isDraft): ?>
  <!-- draft: the order only -->
  <div class="table-wrap">
    <table class="table table-bordered align-middle doc-table doc-order">
      <colgroup>
        <col style="width:4%"><col style="width:52%"><col style="width:11%">
        <col style="width:11%"><col style="width:8%"><col style="width:14%">
      </colgroup>
      <thead>
        <tr>
          <th>#</th>
          <th>Item</th>
          <th class="num">Qty Ordered</th>
          <th class="num">Unit Rate</th>
          <th class="num">GST %</th>
          <th class="num">Total Amount</th>
        </tr>
      </thead>
      <tbody>
      <?php $n = 0; foreach ($lines as $l): $n++; ?>
        <tr>
          <td><?= $n ?></td>
          <td>
            <div class="fw-semibold"><?= h($l['item_name']) ?></div>
            <div class="help mono"><?= h($l['item_code']) ?></div>
          </td>
          <td class="num"><?= qty_str($l['ordered_qty']) ?> <?= h($l['unit']) ?></td>
          <td class="num"><?= money($l['unit_rate'], false) ?></td>
          <td class="num"><?= qty_str($l['gst_percent']) ?>%</td>
          <td class="num fw-semibold"><?= money($l['line_total'], false) ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
      <tfoot>
        <tr><td colspan="5" class="text-end">Sub total</td><td class="num"><?= money($po['sub_total'], false) ?></td></tr>
        <tr><td colspan="5" class="text-end">GST</td><td class="num"><?= money($po['gst_total'], false) ?></td></tr>
        <tr class="table-light">
          <td colspan="5" class="text-end fw-bold">Order Value</td>
          <td class="num fw-bold"><?= money($po['grand_total']) ?></td>
        </tr>
      </tfoot>
    </table>
  </div>

  <?php else: ?>
  <!-- received: ordered vs received vs not received, with GST -->
  <div class="table-wrap">
    <table class="table table-bordered align-middle doc-table doc-grn">
      <colgroup>
        <col style="width:3%"><col style="width:45%"><col style="width:8%">
        <col style="width:8%"><col style="width:7%"><col style="width:10%">
        <col style="width:8%"><col style="width:11%">
      </colgroup>
      <thead>
        <tr>
          <th>#</th>
          <th>Item</th>
          <th class="num">Ordered Qty</th>
          <th class="num">Received Qty</th>
          <th class="num">Not Received</th>
          <th class="num">Unit Rate</th>
          <th class="num">GST %</th>
          <th class="num">Total Amount</th>
        </tr>
      </thead>
      <tbody>
      <?php $n = 0;
      $sumRcvSub = 0.0; $sumRcvGst = 0.0;
      foreach ($lines as $lineId => $l):
          $n++;
          $rws     = $receipts[$lineId] ?? [];
          $gotQty  = (float)$l['received_qty'];
          $dueQty  = (float)$l['balance_qty'];
          $rcvSub  = (float)$l['received_sub'];
          $rcvGst  = (float)$l['received_gst'];
          $sumRcvSub += $rcvSub;
          $sumRcvGst += $rcvGst;
          /* the rate and GST actually received - the ordered one if nothing came */
          $rate = $gotQty > 0 ? $rcvSub / $gotQty : (float)$l['unit_rate'];
          $gstPc = $rcvSub > 0 ? round($rcvGst / $rcvSub * 100, 2) : (float)$l['gst_percent'];
      ?>
        <tr<?= $gotQty <= 0 ? ' class="table-warning"' : '' ?>>
          <td><?= $n ?></td>
          <td>
            <div class="fw-semibold"><?= h($l['item_name']) ?></div>
            <div class="help mono"><?= h($l['item_code']) ?></div>
            <?php if ($rws): ?>
              <div class="help lot-lines">
                <?php $bits = [];
                foreach ($rws as $d) {
                    $bits[] = '<span class="lot-bit">lot <b>' . h(lot_label($d['lot_number'])) . '</b>'
                            . ' &times; ' . qty_str($d['quantity'])
                            . ($d['expiry_date'] ? ', exp ' . dmy($d['expiry_date']) : '')
                            . ' <span class="text-muted">(GRN #' . (int)$d['receipt_no'] . ')</span></span>';
                }
                echo implode(' ', $bits); ?>
              </div>
            <?php endif; ?>
          </td>
          <td class="num"><?= qty_str($l['ordered_qty']) ?> <?= h($l['unit']) ?></td>
          <td class="num fw-semibold"><?= qty_str($gotQty) ?></td>
          <td class="num">
            <?php if ($dueQty > 0.005): ?>
              <span class="badge badge-soft-warning"><?= qty_str($dueQty) ?></span>
            <?php elseif ((float)$l['over_qty'] > 0.005): ?>
              <span class="badge badge-soft-danger">+<?= qty_str($l['over_qty']) ?> extra</span>
            <?php else: ?>
              <span class="text-muted">-</span>
            <?php endif; ?>
          </td>
          <td class="num">
            <?= money($rate, false) ?>
            <?php if ($gotQty > 0 && abs($rate - (float)$l['unit_rate']) >= 0.005): ?>
              <div class="help">ordered <?= money($l['unit_rate'], false) ?></div>
            <?php endif; ?>
          </td>
          <td class="num"><?= qty_str($gstPc) ?>%
            <?php if ($rcvGst > 0): ?><div class="help"><?= money($rcvGst, false) ?></div><?php endif; ?>
          </td>
          <td class="num fw-semibold"><?= money($rcvSub + $rcvGst, false) ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
      <tfoot>
        <tr class="tf-qty">
          <td colspan="2" class="text-end fw-semibold">Total quantity</td>
          <td class="num fw-semibold"><?= qty_str($totalOrdQty) ?></td>
          <td class="num fw-semibold"><?= qty_str($totalGotQty) ?></td>
          <td class="num fw-semibold"><?= qty_str($totalDueQty) ?></td>
          <td colspan="2" class="text-end">Sub total received</td>
          <td class="num"><?= money($sumRcvSub, false) ?></td>
        </tr>
        <tr>
          <td colspan="7" class="text-end">GST received</td>
          <td class="num"><?= money($sumRcvGst, false) ?></td>
        </tr>
        <tr class="table-light">
          <td colspan="7" class="text-end fw-bold">Total Received</td>
          <td class="num fw-bold"><?= money($sumRcvSub + $sumRcvGst) ?></td>
        </tr>
        <tr>
          <td colspan="7" class="text-end">Ordered value (for comparison)</td>
          <td class="num"><?= money($po['grand_total'], false) ?></td>
        </tr>
      </tfoot>
    </table>
  </div>
  <?php endif; ?>

  <div class="small text-muted mt-2">
    Amount in words:
    <b><?= h(ucwords(amount_in_words((float)($isDraft ? $po['grand_total'] : $po['received_total'])))) ?></b>
  </div>

  <div class="sign-row">
    <div class="sign-box"><?= $isDirect ? 'Entered By' : 'Prepared By' ?><?= $po['created_by_name'] ? '<br><span class="small text-muted">' . h($po['created_by_name']) . '</span>' : '' ?></div>
    <div class="sign-box">Received &amp; Checked By<?= (!$isDraft && $po['finalized_by_name']) ? '<br><span class="small text-muted">' . h($po['finalized_by_name']) . '</span>' : '' ?></div>
    <div class="sign-box">Authorised Signatory<br><span class="brand-font"><?= h(APP_BRAND) ?></span></div>
  </div>
</div>

<!-- --------------------- next step / pending balance ------------------- -->
<?php if ($isOpen): ?>
<div class="card mt-3 no-print">
  <div class="card-body d-flex flex-wrap align-items-center gap-3">
    <i class="bi bi-box-arrow-in-down fs-3 text-navy"></i>
    <div class="flex-grow-1">
      <b><?= $isPartial ? 'Balance still to come' : 'Goods arrived?' ?></b>
      <div class="help">
        <?php if ($isPartial): ?>
          <?= qty_str($totalDueQty) ?> unit(s) are still due on this order. Post them as they come,
          with their own lot number and expiry date - the order closes itself once everything is in.
        <?php else: ?>
          Open Receive (GRN) to post the quantity, rate, GST and lot numbers actually delivered.
          A part delivery can be posted now and the balance later.
        <?php endif; ?>
      </div>
    </div>
    <a href="receive_po.php?id=<?= (int)$po['id'] ?>" class="btn btn-primary">
      <i class="bi bi-box-arrow-in-down"></i> <?= $isPartial ? 'Receive Balance' : 'Receive (GRN)' ?>
    </a>
  </div>
</div>
<?php endif; ?>

<!-- ------------------------- STOCK LOTS CREATED ----------------------- -->
<?php if ($batches): ?>
<div class="card mt-3 no-print">
  <div class="card-header"><i class="bi bi-layers"></i> Stock Lots Created / Updated by this document</div>
  <div class="table-wrap">
    <table class="table table-striped mb-0">
      <thead>
        <tr><th>Item</th><th>Lot</th><th>Expiry</th><th class="num">Rate</th>
            <th class="num">GST %</th><th class="num">Qty Now Available</th><th class="num">Value</th></tr>
      </thead>
      <tbody>
      <?php foreach ($batches as $b): $e = expiry_meta($b['expiry_date']); ?>
        <tr>
          <td><?= h($b['item_name']) ?></td>
          <td><span class="lot-chip<?= lot_label($b['lot_number']) === GENERAL_LOT ? ' general' : '' ?>"><?= h(lot_label($b['lot_number'])) ?></span></td>
          <td><?= dmy($b['expiry_date']) ?>
              <span class="badge badge-soft-<?= $e['css'] === 'secondary' ? 'secondary' : ($e['css'] === 'success' ? 'success' : ($e['css'] === 'warning' ? 'warning' : 'danger')) ?>"><?= h($e['label']) ?></span>
          </td>
          <td class="num"><?= money($b['unit_price'], false) ?></td>
          <td class="num"><?= qty_str($b['gst_percent']) ?>%</td>
          <td class="num"><?= qty_str($b['quantity_available']) ?> <?= h($b['unit']) ?></td>
          <td class="num"><?= money((float)$b['quantity_available'] * (float)$b['unit_price'], false) ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <div class="card-footer help">
    Stock is valued at the base rate, without GST. Quantity shown is what is
    <b>available today</b> - it reduces as the lot is issued through Stock Out.
  </div>
</div>
<?php endif; ?>

<?php if (get_int('print') === 1): ?>
<script>window.addEventListener('load', function () { window.print(); });</script>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>
