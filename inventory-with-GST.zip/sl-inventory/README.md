# SL Diagnostics — Laboratory Inventory & Stock Management System

Core PHP (PDO) + MySQL + Bootstrap 5 + vanilla JS. No framework, no composer, no build step.
Runs on XAMPP locally and on cPanel/LiteSpeed shared hosting as-is.

**This build: clean database, login with Admin / User roles, your logo on the printed PO,
and the two-stage Order → Receive (GRN) purchase workflow.**

---

## 1. Folder structure

```
sl-inventory/
├── database.sql              Clean MySQL schema + ONE default admin login
├── livedb.sql                YOUR data: 9 depts, 20 analysers, 33 suppliers,
│                             220 items and the opening stock as on 31-10-2026
├── db_update.sql             ONE update file for an existing database. Safe to
│                             re-run; replaces all the old upgrade_vN files
├── logo.png                  ← PUT YOUR LOGO HERE (see section 5)
├── db.php                    App constants, session settings, PDO (EDIT THIS)
├── login.php                 Sign in (split-panel on desktop, single column on mobile)
├── logout.php                Sign out
├── index.php                 Dashboard — stock value, low stock, expiry, POs to receive
├── suppliers.php             Supplier master (CRUD)
├── items.php                 Item master (CRUD): lot switch, dept, analyser, supplier
├── departments.php           Departments + the equipment / analysers inside them
├── budget.php                Monthly budget — the Excel sheet, inside the system
├── create_po.php             Raise / edit a Draft PO (AJAX rate auto-fill)
├── receive_po.php            Receive (GRN) — qty, rate, lot numbers, then finalize
├── direct_grn.php            Direct GRN — goods received with no purchase order
├── po_list.php               PO register — ordered vs received, variance
├── view_po.php               PO view + A4 print with logo + goods-received comparison
├── stock_report.php          Stock & valuation (lot-wise / item-wise) + CSV export
├── stock_out.php             Issue voucher — many items per slip + issue register
├── users.php                 User Management  ← ADMIN ONLY
├── profile.php               My Account — own name + own password (both roles)
├── includes/
│   ├── functions.php         Helpers + ALL stock business logic
│   ├── auth.php              Login session, roles, page guards
│   ├── header.php            <head>, sidebar, topbar  (set $page_title, $active)
│   └── footer.php            Closing markup + scripts
├── ajax/
│   ├── get_last_rate.php     ?item_id=&supplier_id= → last purchase rate + item info
│   └── get_batches.php       ?item_id= → available lots in FIFO order
└── assets/
    ├── css/style.css         Theme, login page, responsive sidebar, print stylesheet
    └── js/app.js             Shared JS (number formatting, fetch wrapper, confirms)
```

## 2. Installation

1. Copy the `sl-inventory` folder into `htdocs` (XAMPP) or `public_html` (cPanel).
2. Import `database.sql` — phpMyAdmin → Import, or:
   ```
   mysql -u root -p < database.sql
   ```
   It creates `sl_inventory`, all eleven tables, the `v_item_stock` view and **one** row:
   the default administrator. No suppliers, items or stock.
   Then import `livedb.sql` to load your real masters and the opening stock
   (section 5). Skip it only if you want to type everything in by hand.
3. Edit the top of **`db.php`**:
   ```php
   define('DB_HOST', 'localhost');
   define('DB_NAME', 'sl_inventory');
   define('DB_USER', 'root');      // cPanel: your DB user
   define('DB_PASS', '');          // cPanel: your DB password
   ```
   `APP_ADDRESS` / `APP_GST` there print on the purchase order.
   `SESSION_IDLE_MINUTES` (240), `LOGIN_MAX_ATTEMPTS` (5) and `LOGIN_LOCK_MINUTES` (5)
   control the session and the brute-force brake.
4. Open `login.php`:

   | | |
   |---|---|
   | Username | `admin` |
   | Password | `admin123` |

   **Change this immediately** — log in, open **My Account**, set a new password.
5. Requires PHP 7.4+ (tested on PHP 8.3) with `pdo_mysql`.

**First-run order:** login → Suppliers → Item Master → Create PO (saved as Draft) →
when the goods arrive, **Receive (GRN)** → Finalize → Stock Out.
The dashboard shows a Getting Started checklist until the masters have data, and lists every
PO still waiting to be received.

**Already have a database with data in it?** Import **`db_update.sql`** — one file, and it is
safe to run again: every step checks itself and prints "already there" instead of failing with
#1060 / #1061 / #1050. It adds everything that came after the first version (receipts, GST,
part deliveries, departments, equipment, the budget table, issue vouchers, direct GRNs),
back-fills the existing rows and rebuilds the view. A fresh install does not need it.

**Three documents, three number series** — all defined at the top of `db.php`, so renaming any
of them is a one-line change that every page follows:

| Document | Number | What it is |
|---|---|---|
| **Purchase Order** (`DOC_PREFIX`) | `PO/2026-27/0001` | What we ordered. Always a Draft until the goods arrive. |
| **Goods Receive Note** (`GRN_PREFIX`) | `GRN/2026-27/0001` | Goods received **without** a purchase order — `direct_grn.php`. |
| **Issue Voucher** (`ISSUE_PREFIX`) | `ISS/2026-27/0001` | Stock issued to a department. |

Receiving against a purchase order keeps that order's own `PO/…` number — the received copy
of the order *is* its goods receive note, which is why the printed sheet is headed
"Purchase Order" while it is a Draft and "Goods Receive Note" once it has been received.

## 3. Roles

| Page | Admin | User |
|---|---|---|
| Dashboard, Suppliers, Item Master, Departments | ✔ | ✔ |
| Monthly Budget, requirement, draft POs from it | ✔ | ✔ |
| Create PO, Purchase Orders, Final conversion, Print | ✔ | ✔ |
| Stock & Valuation, CSV export, Stock Out, Reverse | ✔ | ✔ |
| My Account (own name / password) | ✔ | ✔ |
| **User Management (create logins, set roles)** | ✔ | ✖ |

A User can use every page except `users.php`; only an Admin can create logins. The guard is
server-side — `require_login()` on every page and `require_admin()` on `users.php` — so typing
the URL directly does not get a User in; the menu item is hidden as well. The ajax endpoints
answer `401` to a dead session instead of leaking data.

Admin can create, edit, deactivate and delete logins, reset any password, and switch a login
between Admin and User. Guards that cannot be overridden from the UI: you cannot delete or
deactivate your own login, and the **last active Admin** cannot be deleted, deactivated or
demoted — so the system can never be locked out.

Passwords are stored as bcrypt hashes (`password_hash`), never in plain text. Other security:
CSRF token on every form, prepared statements everywhere, `h()` on all output, HttpOnly +
SameSite=Lax session cookie (Secure automatically over HTTPS), session ID regenerated on login,
idle timeout, a 5-attempt lockout, and a whitelist on the post-login redirect.

Every purchase order stores who created it and who finalized it; every stock-out line stores who
issued it. These names show on the PO register, the PO view (also under "Prepared By" when
printed) and the issue register, and survive the deletion of that login.

## 4. How the stock logic works

**Multi-lot items** — `items.has_lot = 1` means every purchase creates/updates a row in
`item_batches` carrying its own `lot_number`, `expiry_date`, `supplier_id` and `unit_price`.
`has_lot = 0` items (gloves, tubes, stationery) are stored under the reserved lot `GENERAL`
with a NULL expiry; the PO form hides those two fields automatically.

**Valuation** — no average costing. Each lot keeps the rate it was bought at, so

```
Current Total Stock Value = SUM(item_batches.quantity_available * item_batches.unit_price)
```

is exact even when the same item was bought from three suppliers at three rates.

**PO workflow — order first, receive second**

A purchase order can **never** be finalized straight from the order screen. It is always saved
as a Draft, and stock is created only after the delivery is physically checked in.

| Stage | Page | Effect |
|---|---|---|
| **1. Order** | `create_po.php` | Item, quantity, expected rate. Always saved as **Draft**. `item_batches` untouched, nothing in the valuation. Editable and deletable. No lot numbers asked for. |
| **2. Receive (GRN)** | `receive_po.php` | What actually arrived: correct the quantity, correct the rate if the supplier hiked it, enter lot numbers and expiry dates, split one ordered line across several lots. Can be **saved** without finalizing (part delivery) — the PO stays Draft. |
| **3. Close** | `receive_po.php` | Once every line is fully received the PO closes itself (**Final**). It can also be closed short, when the supplier will not send the balance. |

### Part deliveries

A delivery rarely arrives all at once, so a receipt posts **only what you enter**:

- Each ordered line shows **ordered / received so far / balance**, and the quantity box is
  pre-filled with the balance.
- Post 6 of the 10 ordered with their lot and expiry, and the PO becomes **Partial** — still
  open, with 4 pending. Post the rest later, on its own lot numbers and expiry dates, and the
  PO closes itself.
- A lot-tracked line **cannot** be posted without its lot number. If the lot is not known yet,
  clear that quantity and receive it on the next GRN — nothing is held half-entered.
- `receipt_no` numbers the deliveries (1, 2, 3 …) and every posted row records its batch, the
  time and the user.
- An over-delivery is allowed and flagged; a shortfall shows as *not received*.
- **Close without receiving** ends an order whose balance will never arrive. Stock already
  posted stays exactly as it is.

**Goods that arrive without an order** go through `direct_grn.php` instead — an urgent supply,
a free replacement, a sample, something bought over the counter. One screen: GRN number (its
own `GRN/…` series), supplier, date, invoice number, then the items with their lot, expiry,
quantity and rate. Saving posts the stock immediately — no draft, no separate receive step.

**What the GRN view shows once it is received** — per item: *ordered qty, received qty, not
received qty, unit rate, GST % and total amount*, with the lot numbers and expiry dates of each
receipt under the item name, the rate shown against the ordered rate whenever it changed, and
totals for sub total received / GST received / total received against the ordered value. That
is the table that prints.

Behind the scenes a direct GRN is stored exactly like a received purchase order
(`purchase_orders.is_direct = 1`) with the ordered lines mirroring what was received, so it
shows no variance, and the stock report, the valuation, the last-rate lookup and the monthly
budget all count it the same as any other receipt. The register tags it **Direct GRN** and can
filter on it, and the printed sheet says the goods came in without a purchase order.
Put the same item on two rows with different lot numbers to receive it in two lots.

Ordered and received are stored separately and never overwrite each other:

| | |
|---|---|
| `po_items` + `purchase_orders.grand_total` | what we asked |
| `po_receipts` + `purchase_orders.received_total` | what they gave |

So a PO ordered at ₹1,000 and delivered 8 of 10 at a hiked rate of ₹110 keeps the ₹1,000 order
on record and posts ₹880 of stock. The difference is shown on the PO register, on the PO view
and on the printed sheet. Stock is always valued at the rate actually received, never the rate
ordered.

**Splitting a line across lots** — on the Receive screen each ordered line has an *Add another
lot for this item* button. Ten kits delivered as 5 of lot `AS123` and 5 of lot `AR123` become
two receipt rows and two separate stock lots, each with its own expiry and rate. The screen
shows the received quantity and value against the ordered figures line by line, so a short
delivery or a price change is visible before you commit.

`finalize_po()` in `includes/functions.php` is the **only** place stock is created. It is
transaction-wrapped and flips the status with `UPDATE … WHERE id = ? AND status = 'Draft'`,
so a double-click or two users finalizing at once can never post the same quantity twice.
Finalizing with no confirmed receipt rows is refused. A received line merges into an existing
lot only when item + supplier + lot + expiry + rate all match; any difference opens a new lot
row so valuation stays accurate. Each receipt row keeps `batch_id`, so every stock lot traces
back to the exact PO line it came from.

**Rate and GST auto-fill** — picking an item in the PO or GRN form calls
`ajax/get_last_rate.php`, which returns both the **rate** and the **GST %** last received for
that item: first from that supplier, then from any supplier, then the opening-stock rate, and
finally the item master's own default. Both fields stay fully editable, and once you type in
one, changing the supplier will not overwrite your value.

**GST** is entered as a **percentage per line**, on both the PO and the GRN, and is added on
top of the rate:

```
taxable  = qty × rate
GST      = taxable × GST% / 100
line     = taxable + GST
```

The PO and the GRN each carry **sub total / GST / grand total**. Every receipt remembers the
GST % it used against the item (`items.default_gst_percent`), so the next purchase of that item
suggests it without being asked — the same way the rate is remembered. A default can also be
typed into the Item Master directly, and the Budget page puts it on the draft POs it raises.

**Stock is valued on the base rate, without GST** — `item_batches.unit_price` is the taxable
rate, so the dashboard, the stock report and the issue values are all ex-GST and reconcile with
the Excel sheet. The lot keeps its GST % alongside, for reference.

**Searching for items** — every long dropdown (items, suppliers) has a small filter box above
it. Type two or three letters, press Enter to take the first match, Esc to clear. It is plain
JavaScript, no library, and it works in the PO rows, the GRN rows, the issue voucher, the stock
report and the budget filters — including rows added with *Add Row*.

**Stock out — the issue voucher**

One voucher is one slip: a date, a department, a voucher number and the person who collected
the goods, then as many items as needed underneath. The header is entered in that order, and
the voucher number is auto-filled as `ISS/2026-27/0001` but stays editable so it can match the
numbers in your register book. "Received by" is typed in by hand.

Each line is taken **FIFO** (earliest expiry first, lots without an expiry last, spanning as
many lots as needed) or from **one lot you pick** from that item's live lot list. Every slice
writes a `stock_out` row with the lot's own rate, so the consumption value is historically
correct, and all the lines of a voucher share one `voucher_no`.

Saving is all-or-nothing: `issue_voucher()` wraps the whole slip in one transaction, so if the
third item is short of stock, the first two are rolled back too and nothing is issued — you
never get half a voucher. Short quantities are rejected in full, never partially.

After saving, the voucher prints as a slip with your logo, the lot numbers, the values and
signature lines for *Issued By* and *Received By*. In the register each voucher is shown as a
block, and can be reversed one line at a time or whole — the quantity goes back to the same lot.

## 5. Your Excel budget, inside the system

`livedb.sql` carries the real data read out of `Nov2026_budget.xls` (Sheet4 — the
Dept / Equipment / Supplier / Item sheet). Import it after `database.sql`:

```
mysql -u root -p < database.sql
mysql -u root -p < livedb.sql
```

It loads the masters and **the opening stock only** — the closing balance of October 2026.
The October movement figures and the November requirement are deliberately left out: from here
on, purchases come from the GRNs and issues from the vouchers, and the system works the monthly
figures out itself.

| Loaded | |
|---|---|
| Departments | 9 — Biochemistry, Haematology, Microbiology, GCC, Radiology, Ultrasound, Sample Collection, Diagnostics, General |
| Equipment | 20 — AU480, Beckman Unicel Dxc, Mini Vidas, Coagulometer, D10, Erba Chem, Meril, Abbott, EM360, H360, Cobas Urine Analyser, Erba H7100, Mindray, Mispa i3, Elisa, Cultures, Manual, Vaccine … |
| Suppliers | 33 |
| Items | 220, each with its department, analyser, default supplier and item code |
| Opening stock | 108 lots = the sheet's closing stock as on 31-10-2026, **₹7,88,810.53** |
| Opening balance | one row per item for October 2026 carrying that closing stock, so the Budget page opens November with the right opening |

The opening stock totals ₹7,88,810.53 across 12,092 units — the same figure your sheet closed
on, to the paisa.

Three things to know about the import:

1. **An item used by more than one department is one store item.** The sheet carries
   "slides" under Haematology and Sample Collection separately; the system holds one item with
   the quantities added, and the department now comes from each issue entry instead. 244 sheet
   rows became 220 items that way.
2. **Lot tracking was switched on for 146 of the 220 items** — everything that sits on an
   analyser, plus names that read like a reagent, kit, calibrator or control. The other 74
   (syringes, films, stationery) are no-lot items. Change any of them in the Item Master.
3. **Opening stock has no lot number, expiry or GST** — the sheet does not carry them.
   Lot-tracked items hold a lot called `OPENING` until you replace it, e.g.
   `UPDATE item_batches SET lot_number='AS123', expiry_date='2027-06-30' WHERE item_id=12 AND lot_number='OPENING';`
   Every lot received from now on carries its real number from the Receive screen.
   `unit` defaults to `Nos` and GST % to 0 — set the GST once per item in the Item Master and
   every PO and GRN will suggest it from then on.

### The Budget page

`budget.php` is the sheet itself, live. Pick a month and it shows, per item:

```
Opening  ->  Purchase  ->  Issues  ->  Closing  ->  Required for next month
```

grouped **Dept / Equipment** (as in Sheet3 and Sheet4) or **Supplier wise** (as in Sheet5 and
Sheet6), with sub-totals per group and a grand total. October 2026 carries only the imported
opening balance; every month from November onwards the system works the figures out from its
own data — purchases from the posted GRN receipts (including part deliveries), issues from the
Stock Out register, and `closing = opening + purchase − issues`, exactly as the sheet does it.

- **Required qty** is editable per item. *Fill suggested* writes `issues × cover − closing`
  into every blank row, where *cover* (default 2 months) is yours to set — that is close to how
  the sheet's Reqd column reads today. The rate is editable too.
- **Save Requirement** stores it against the month.
- **Close month** freezes the figures so that month's closing becomes the next month's opening.
  That is what keeps the chain going, the same way one sheet tab feeds the next.
- **Create Draft POs (supplier wise)** turns the saved requirement into one Draft purchase
  order per supplier, using each item's default supplier — your Sheet6 supplier-wise budget,
  raised as actual POs in one click. Items with no supplier set are skipped and listed.
  Nothing enters stock until each PO is received and finalized.
- **Export** gives the same table as CSV, so the monthly file can still be mailed as before.

Departments and analysers are maintained in `departments.php`, and every Stock Out entry now
picks a department from that list, which is what makes the department-wise consumption in the
budget accurate.

## 6. Your logo

Put `logo.png` in the application root, next to `db.php`. It is used automatically on:

- the **printed purchase order** header (left side, beside the address / GSTIN),
- the **login page** (on a white panel, so a dark or coloured logo still reads),
- the **sidebar** brand area,
- the **browser tab** icon.

Nothing breaks if the file is missing — every spot falls back to the text wordmark
"SL Diagnostics" in Times New Roman Bold. A wide logo that already contains the full name works
best: it is capped at 64px tall on the PO, 66px on login and 46px in the sidebar, and the width
scales automatically. Replacing the file is enough — the `?v=` on the URL is the file's own
modified time, so the new logo appears immediately instead of a cached one. To use a different
file name, change `APP_LOGO` in `db.php`.

## 7. Notes

- Bootstrap 5.3 and Bootstrap Icons load from jsDelivr. To go CDN-free, download
  `bootstrap.min.css`, `bootstrap.bundle.min.js` and the icons font into `assets/`
  and change the tags in `includes/header.php`, `includes/footer.php` and `login.php`.
- Entering opening stock without a purchase order: either raise one PO per supplier with the
  current rates and receive it with the real lot numbers (recommended — it keeps the audit
  trail), or insert the rows straight into `item_batches`.
- Editing a Draft PO after a receipt has been saved against it clears that saved receipt, since
  the ordered lines it referred to are replaced.
- Deletions are protected by referential checks: a supplier with POs, an item used in a PO or
  still holding stock, and any Final PO cannot be deleted; deactivate instead.
- Columns beyond the original spec: `is_active` on `suppliers`/`items`/`users`,
  `created_by` / `finalized_by` / `finalized_at` / `received_total` / `receive_date` /
  `invoice_no` / `receive_notes` on `purchase_orders`, `po_id` on `item_batches`
  (PO → lot traceability), `issued_by` on `stock_out`, plus the `users`, `po_receipts` and
  `stock_out` tables and the `v_item_stock` view. `po_items.lot_number` / `expiry_date` remain
  in the schema but are no longer filled by the order screen — lot details live in
  `po_receipts`.
