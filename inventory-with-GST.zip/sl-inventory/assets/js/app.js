/* ============================================================================
   SL Diagnostics - Inventory Management
   assets/js/app.js  (vanilla JS, no dependencies beyond Bootstrap bundle)
   ============================================================================ */
(function () {
  'use strict';

  /* --------------------------------------------------------------------- */
  /* number helpers                                                        */
  /* --------------------------------------------------------------------- */
  window.SL = {
    num: function (v) {
      var n = parseFloat(String(v === undefined || v === null ? '' : v).replace(/,/g, ''));
      return isNaN(n) ? 0 : n;
    },
    money: function (v) {
      return (Math.round(SL.num(v) * 100) / 100).toLocaleString('en-IN', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
      });
    },
    /** GET a JSON endpoint; always resolves to an object. */
    getJSON: function (url) {
      return fetch(url, { headers: { 'X-Requested-With': 'fetch' }, credentials: 'same-origin' })
        .then(function (r) { return r.ok ? r.json() : { ok: false, error: 'HTTP ' + r.status }; })
        .catch(function (e) { return { ok: false, error: String(e) }; });
    }
  };

  /* --------------------------------------------------------------------- */
  /* searchable <select> - no library, works on desktop and mobile          */
  /* Any <select class="js-search"> gets a small filter box above it.       */
  /* Typing hides the options that do not match, so the native dropdown     */
  /* (and the mobile picker) only shows what is left. Enter picks the first  */
  /* remaining option.                                                      */
  /* --------------------------------------------------------------------- */
  function searchify(sel) {
    if (!sel || sel.dataset.searchified === '1' || sel.options.length < 12) { return; }
    sel.dataset.searchified = '1';

    var box = document.createElement('input');
    box.type = 'text';
    box.className = 'form-control form-control-sm js-search-box';
    box.placeholder = 'type to filter ' + (sel.options.length - 1) + ' items...';
    box.autocomplete = 'off';
    box.tabIndex = -1;

    var wrap = document.createElement('div');
    wrap.className = 'js-search-wrap';
    sel.parentNode.insertBefore(wrap, sel);
    wrap.appendChild(box);
    wrap.appendChild(sel);

    function filter() {
      var q = box.value.toLowerCase().trim();
      var shown = 0, firstHit = null;
      for (var i = 0; i < sel.options.length; i++) {
        var o = sel.options[i];
        if (o.value === '' || o.value === '0') { o.hidden = false; continue; }   /* keep the placeholder */
        var hit = !q || o.text.toLowerCase().indexOf(q) !== -1;
        o.hidden = !hit;
        if (hit) { shown++; if (!firstHit) { firstHit = o; } }
      }
      box.classList.toggle('is-invalid', q !== '' && shown === 0);
      box.dataset.first = firstHit ? firstHit.value : '';
    }

    box.addEventListener('input', filter);
    box.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') {
        e.preventDefault();
        if (box.dataset.first) {
          sel.value = box.dataset.first;
          sel.dispatchEvent(new Event('change', { bubbles: true }));
          box.value = '';
          filter();
          sel.focus();
        }
      }
      if (e.key === 'Escape') { box.value = ''; filter(); }
    });
    /* once something is chosen, clear the filter so the full list is back */
    sel.addEventListener('change', function () {
      if (box.value !== '') { box.value = ''; filter(); }
    });
  }

  window.SL.searchify = searchify;
  window.SL.searchifyAll = function (root) {
    (root || document).querySelectorAll('select.js-search').forEach(searchify);
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () { SL.searchifyAll(); });
  } else {
    SL.searchifyAll();
  }

  /* --------------------------------------------------------------------- */
  /* confirm-before-submit / before-navigate                               */
  /* --------------------------------------------------------------------- */
  document.addEventListener('click', function (e) {
    var el = e.target.closest('[data-confirm]');
    if (el && !window.confirm(el.getAttribute('data-confirm'))) {
      e.preventDefault();
      e.stopPropagation();
    }
  });

  document.addEventListener('submit', function (e) {
    var f = e.target;
    if (f.hasAttribute('data-confirm') && !window.confirm(f.getAttribute('data-confirm'))) {
      e.preventDefault();
    }
  });

  /* --------------------------------------------------------------------- */
  /* instant client side table filter: <input data-filter="#tableId">      */
  /* --------------------------------------------------------------------- */
  document.addEventListener('input', function (e) {
    var box = e.target;
    if (!box.matches('[data-filter]')) return;
    var table = document.querySelector(box.getAttribute('data-filter'));
    if (!table) return;
    var q = box.value.toLowerCase().trim();
    var rows = table.tBodies.length ? table.tBodies[0].rows : [];
    var shown = 0;
    for (var i = 0; i < rows.length; i++) {
      var hit = rows[i].textContent.toLowerCase().indexOf(q) !== -1;
      rows[i].style.display = hit ? '' : 'none';
      if (hit) shown++;
    }
    var out = document.querySelector('[data-filter-count]');
    if (out) out.textContent = shown + ' row(s)';
  });

  /* --------------------------------------------------------------------- */
  /* auto dismiss flash messages                                           */
  /* --------------------------------------------------------------------- */
  window.setTimeout(function () {
    document.querySelectorAll('.alert-success.alert-dismissible').forEach(function (a) {
      if (window.bootstrap && bootstrap.Alert) {
        bootstrap.Alert.getOrCreateInstance(a).close();
      }
    });
  }, 7000);

})();
