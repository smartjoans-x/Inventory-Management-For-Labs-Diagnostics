<?php
/* ============================================================================
   receive_po.php - Goods Receive Note (GRN) against a purchase order
   ----------------------------------------------------------------------------
   This is where "what we asked" becomes "what they gave":
     - the quantity delivered can be lower (or higher) than ordered
     - the rate and the GST % can differ from the order
     - lot numbers and expiry dates are entered here
     - one ordered line can be split across several lots
     - a delivery can be received IN PARTS: post what arrived with its lot and
       expiry, leave the rest blank, and the purchase order stays open as
       Partial until the balance is posted on a later receipt

   Every receipt is posted to stock the moment it is saved. Nothing sits
   half-entered: a line with no lot number yet is simply left for next time.
   ============================================================================ */
require_once __DIR__ . '/db.php';
require_login();

$poId = get_int('id') ?: post_int('po_id');

$st = $pdo->prepare('SELECT po.*, s.supplier_name, s.gst_no, s.contact_person, s.phone
                     FROM purchase_orders po
                     JOIN suppliers s ON s.id = po.supplier_id
                     WHERE po.id = ?');
$st->execute([$poId]);
$po = $st->fetch();

if (!$po) {
    flash('Purchase order not found.', 'warning');
    redirect('po_list.php');
}
if ($po['status'] === 'Final') {
    flash('PO <b>' . h($po['po_number']) . '</b> is closed - everything has been received and posted.', 'info');
    redirect('view_po.php?id=' . $poId);
}

/* ------------------------------- ACTIONS --------------------------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = post_str('action');

    if ($action === 'close_only') {
        $res = close_po($pdo, $poId, user_id());
        flash(h($res['message']), $res['ok'] ? 'success' : 'warning');
        redirect('view_po.php?id=' . $poId);
    }

    $qtyIn  = isset($_POST['qty'])    && is_array($_POST['qty'])    ? $_POST['qty']    : [];
    $rateIn = isset($_POST['rate'])   && is_array($_POST['rate'])   ? $_POST['rate']   : [];
    $gstIn  = isset($_POST['gst'])    && is_array($_POST['gst'])    ? $_POST['gst']    : [];
    $lotIn  = isset($_POST['lot'])    && is_array($_POST['lot'])    ? $_POST['lot']    : [];
    $expIn  = isset($_POST['expiry']) && is_array($_POST['expiry']) ? $_POST['expiry'] : [];

    $rows = [];
    foreach ($qtyIn as $lineId => $qtyList) {
        if (!is_array($qtyList)) {
            continue;
        }
        foreach ($qtyList as $k => $q) {
            if ((float)$q <= 0) {
                continue;
            }
            $rows[] = [
                'po_item_id' => (int)$lineId,
                'qty'        => (float)$q,
                'rate'       => (float)($rateIn[$lineId][$k] ?? 0),
                'gst'        => (float)($gstIn[$lineId][$k]  ?? 0),
                'lot'        => (string)($lotIn[$lineId][$k] ?? ''),
                'expiry'     => (string)($expIn[$lineId][$k] ?? ''),
            ];
        }
    }

    $res = post_receipt($pdo, $poId, $rows, [
        'receive_date'  => post_str('receive_date'),
        'invoice_no'    => post_str('invoice_no'),
        'receive_notes' => post_str('receive_notes'),
    ], user_id(), $action === 'post_close');

    flash($res['ok'] ? 'GRN posted for <b>' . h($po['po_number']) . '</b>. ' . h($res['message'])
                     : h($res['message']),
          $res['ok'] ? 'success' : 'danger');

    redirect($res['ok'] && $res['status'] === 'Final'
             ? 'view_po.php?id=' . $poId
             : 'receive_po.php?id=' . $poId);
}

/* ------------------------- ordered lines + balance ----------------------- */
$lines = po_balance($pdo, $poId);
if (!$lines) {
    flash('This purchase order has no items. <a href="create_po.php?id=' . (int)$poId . '">Edit the draft</a> first.', 'warning');
    redirect('view_po.php?id=' . $poId);
}

/* what has already been posted, grouped by ordered line */
$st = $pdo->prepare('SELECT r.*, u.full_name AS posted_by_name
                     FROM po_receipts r
                     LEFT JOIN users u ON u.id = r.posted_by
                     WHERE r.po_id = ?
                     ORDER BY r.receipt_no, r.id');
$st->execute([$poId]);
$done = [];
$receiptNos = [];
foreach ($st->fetchAll() as $r) {
    $done[(int)$r['po_item_id']][] = $r;
    $receiptNos[(int)$r['receipt_no']] = $r['posted_at'];
}

$orderedTotal  = (float)$po['grand_total'];
$receivedTotal = (float)$po['received_total'];
$pendingLines  = 0;
foreach ($lines as $l) {
    if (!$l['is_complete']) {
        $pendingLines++;
    }
}

$page_title = 'GRN for ' . $po['po_number'];
$page_icon  = 'bi-box-arrow-in-down';
$active     = 'po_list';
require __DIR__ . '/includes/header.php';
?>

<div class="workflow-strip mb-3">
  <div class="wf-step done">
    <span class="wf-num"><i class="bi bi-check"></i></span>
    <div><b>Order</b><div class="help"><?= h($po['po_number']) ?> &middot; <?= money($orderedTotal) ?></div></div>
  </div>
  <i class="bi bi-chevron-right wf-sep"></i>
  <div class="wf-step active">
    <span class="wf-num">2</span>
    <div><b>Receive (GRN)</b>
      <div class="help">
        <?= $po['status'] === 'Partial'
            ? 'Part received - ' . $pendingLines . ' line(s) still due'
            : 'Nothing received yet' ?>
      </div>
    </div>
  </div>
  <i class="bi bi-chevron-right wf-sep"></i>
  <div class="wf-step">
    <span class="wf-num">3</span>
    <div><b>Close</b><div class="help">When everything is in.</div></div>
  </div>
</div>

<form method="post" id="rcvForm" autocomplete="off">
  <?= csrf_field() ?>
  <input type="hidden" name="po_id" value="<?= (int)$poId ?>">
  <input type="hidden" name="action" id="rcvAction" value="post">

  <div class="card mb-3">
    <div class="card-header">
      <i class="bi bi-truck"></i> <?= h($po['supplier_name']) ?>
      <span class="badge badge-soft-secondary ms-2 mono"><?= h($po['po_number']) ?></span>
      <?php if ($po['status'] === 'Partial'): ?>
        <span class="badge badge-soft-warning ms-1">Partly received</span>
      <?php endif; ?>
      <span class="ms-auto help">Ordered <?= dmy($po['po_date']) ?> &middot; <?= money($orderedTotal) ?>
        <?php if ($receivedTotal > 0): ?>
          &middot; received so far <?= money($receivedTotal) ?>
        <?php endif; ?>
      </span>
    </div>
    <div class="card-body">
      <div class="row g-3">
        <div class="col-6 col-md-3">
          <label class="form-label req">Received On</label>
          <input type="date" name="receive_date" class="form-control" required value="<?= h(today()) ?>">
        </div>
        <div class="col-6 col-md-3">
          <label class="form-label">Supplier Invoice / DC No</label>
          <input type="text" name="invoice_no" class="form-control mono" maxlength="60"
                 value="<?= h($po['invoice_no'] ?? '') ?>" placeholder="e.g. INV-4471">
        </div>
        <div class="col-12 col-md-6">
          <label class="form-label">Receipt Remarks</label>
          <input type="text" name="receive_notes" class="form-control" maxlength="500"
                 value="<?= h($po['receive_notes'] ?? '') ?>"
                 placeholder="e.g. 2 kits short, balance promised next week">
        </div>
      </div>

      <?php if ($receiptNos): ?>
        <div class="alert alert-info mt-3 mb-0 py-2 small">
          <i class="bi bi-clock-history"></i>
          Already posted:
          <?php $bits = [];
          foreach ($receiptNos as $no => $when) {
              $bits[] = 'receipt #' . (int)$no . ' on ' . dmy(substr((string)$when, 0, 10));
          }
          echo h(implode(' | ', $bits)); ?>.
          This screen posts the <b>next</b> receipt - only what you enter below.
        </div>
      <?php endif; ?>
    </div>
  </div>

  <!-- =========================== LINE BY LINE =========================== -->
  <?php foreach ($lines as $lineId => $l):
      $hasLot  = (int)$l['has_lot'] === 1;
      $ordQty  = (float)$l['ordered_qty'];
      $gotQty  = (float)$l['received_qty'];
      $balance = (float)$l['balance_qty'];
      $complete = (bool)$l['is_complete'];
  ?>
  <div class="card mb-3 rcv-group <?= $complete ? 'rcv-done' : '' ?>"
       data-line="<?= (int)$lineId ?>" data-has-lot="<?= $hasLot ? 1 : 0 ?>"
       data-ord-qty="<?= h(number_format($ordQty, 2, '.', '')) ?>"
       data-got-qty="<?= h(number_format($gotQty, 2, '.', '')) ?>"
       data-bal-qty="<?= h(number_format($balance, 2, '.', '')) ?>"
       data-unit="<?= h($l['unit']) ?>">
    <div class="card-header">
      <div class="min-w-0">
        <div class="fw-semibold text-truncate"><?= h($l['item_name']) ?></div>
        <div class="help mono"><?= h($l['item_code']) ?>
          <?= $hasLot ? '<span class="badge badge-soft-success ms-1">Lot tracked</span>'
                      : '<span class="badge badge-soft-secondary ms-1">No lot</span>' ?>
        </div>
      </div>
      <div class="ms-auto text-end small d-flex gap-3 flex-wrap justify-content-end">
        <div>
          <div class="text-muted text-uppercase" style="letter-spacing:1px;font-size:.66rem">Ordered</div>
          <div><b><?= qty_str($ordQty) ?></b> <?= h($l['unit']) ?>
               &times; <?= money($l['unit_rate'], false) ?>
               <?php if ((float)$l['gst_percent'] > 0): ?>
                 + <?= qty_str($l['gst_percent']) ?>%
               <?php endif; ?></div>
        </div>
        <div>
          <div class="text-muted text-uppercase" style="letter-spacing:1px;font-size:.66rem">Received</div>
          <div><b><?= qty_str($gotQty) ?></b> <?= h($l['unit']) ?></div>
        </div>
        <div>
          <div class="text-muted text-uppercase" style="letter-spacing:1px;font-size:.66rem">Balance</div>
          <div>
            <?php if ($complete): ?>
              <span class="badge badge-soft-success"><i class="bi bi-check2"></i> complete</span>
            <?php else: ?>
              <b class="text-danger"><?= qty_str($balance) ?></b> <?= h($l['unit']) ?>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>

    <?php if ($done[$lineId] ?? false): ?>
      <div class="px-3 pt-2">
        <div class="small text-muted">Posted already:
          <?php $bits = [];
          foreach ($done[$lineId] as $d) {
              $bits[] = '#' . (int)$d['receipt_no'] . ' ' . qty_str($d['quantity']) . ' '
                      . h($l['unit']) . ' lot ' . h(lot_label($d['lot_number']))
                      . ' @ ' . money($d['unit_rate'], false);
          }
          echo implode(' &middot; ', $bits); ?>
        </div>
      </div>
    <?php endif; ?>

    <?php if (!$complete): ?>
    <div class="table-wrap">
      <table class="table po-table mb-0">
        <thead>
          <tr>
            <th style="min-width:140px">Lot No<?= $hasLot ? ' *' : '' ?></th>
            <th style="min-width:145px">Expiry</th>
            <th style="min-width:120px" class="num">Qty Now</th>
            <th style="min-width:120px" class="num">Rate</th>
            <th style="min-width:110px" class="num">GST %</th>
            <th style="min-width:110px" class="num">Amount</th>
            <th style="width:46px"></th>
          </tr>
        </thead>
        <tbody class="rcv-body">
          <tr class="rcv-row">
            <td data-label="Lot No">
              <input type="text" name="lot[<?= (int)$lineId ?>][]" class="form-control form-control-sm mono rcv-lot"
                     maxlength="80" value="<?= $hasLot ? '' : GENERAL_LOT ?>"
                     placeholder="<?= $hasLot ? 'Lot / Batch No' : 'GENERAL' ?>" <?= $hasLot ? '' : 'readonly' ?>>
            </td>
            <td data-label="Expiry">
              <input type="date" name="expiry[<?= (int)$lineId ?>][]" class="form-control form-control-sm rcv-exp"
                     <?= $hasLot ? '' : 'readonly' ?>>
            </td>
            <td data-label="Qty" class="num">
              <div class="input-group input-group-sm">
                <input type="number" name="qty[<?= (int)$lineId ?>][]" class="form-control form-control-sm text-end rcv-qty"
                       step="0.01" min="0" value="<?= h(qty_str($balance)) ?>">
                <span class="input-group-text" style="min-width:44px"><?= h($l['unit']) ?></span>
              </div>
            </td>
            <td data-label="Rate" class="num">
              <input type="number" name="rate[<?= (int)$lineId ?>][]" class="form-control form-control-sm text-end rcv-rate"
                     step="0.01" min="0" value="<?= h(number_format((float)$l['unit_rate'], 2, '.', '')) ?>">
            </td>
            <td data-label="GST %" class="num">
              <div class="input-group input-group-sm">
                <input type="number" name="gst[<?= (int)$lineId ?>][]" class="form-control form-control-sm text-end rcv-gst gst-pc"
                       step="0.01" min="0" max="100" value="<?= h(number_format((float)$l['gst_percent'], 2, '.', '')) ?>">
                <span class="input-group-text">%</span>
              </div>
            </td>
            <td data-label="Amount" class="num"><span class="row-total rcv-amt">0.00</span></td>
            <td class="text-end">
              <button type="button" class="btn btn-sm btn-outline-danger rcv-del" title="Clear this row">
                <i class="bi bi-x-lg"></i>
              </button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <div class="card-footer d-flex flex-wrap gap-2 align-items-center">
      <button type="button" class="btn btn-sm btn-outline-primary rcv-add">
        <i class="bi bi-plus-lg"></i> Add another lot
      </button>
      <span class="help">
        <?php if ($hasLot): ?>
          Lot number is required to post. No lot yet? Clear the quantity and receive it on the next GRN.
        <?php else: ?>
          No lot number for this item - it goes into the GENERAL lot.
        <?php endif; ?>
      </span>
      <div class="ms-auto text-end small">
        Posting now <b class="rcv-gqty">0</b> <?= h($l['unit']) ?>
        <span class="rcv-gstate"></span>
        &nbsp;|&nbsp; <b class="rcv-gamt">0.00</b>
      </div>
    </div>
    <?php endif; ?>
  </div>
  <?php endforeach; ?>

  <!-- ============================== SUMMARY ============================== -->
  <div class="card sticky-summary">
    <div class="card-body">
      <div class="row g-3 text-center text-md-start">
        <div class="col-6 col-md-3">
          <div class="stat-label">Ordered</div>
          <div class="fs-6 fw-bold text-navy"><?= money($orderedTotal) ?></div>
        </div>
        <div class="col-6 col-md-3">
          <div class="stat-label">Received earlier</div>
          <div class="fs-6 fw-bold"><?= money($receivedTotal) ?></div>
        </div>
        <div class="col-6 col-md-3">
          <div class="stat-label">Posting now</div>
          <div class="fs-6 fw-bold"><?= CURRENCY ?> <span id="postNow">0.00</span>
            <div class="help">incl GST <span id="postGst">0.00</span></div>
          </div>
        </div>
        <div class="col-6 col-md-3">
          <div class="stat-label">Still due after this</div>
          <div class="fs-6 fw-bold"><span id="stillDue">-</span></div>
        </div>
      </div>

      <hr class="my-3">

      <div class="d-flex flex-wrap gap-2 align-items-center">
        <button type="button" class="btn btn-primary" id="btnPost">
          <i class="bi bi-box-arrow-in-down"></i> Post GRN
        </button>
        <button type="button" class="btn btn-outline-primary" id="btnPostClose">
          <i class="bi bi-lock"></i> Post &amp; Close PO
        </button>
        <?php if ($po['status'] === 'Partial'): ?>
          <button type="button" class="btn btn-outline-secondary" id="btnCloseOnly">
            <i class="bi bi-x-circle"></i> Close without receiving
          </button>
        <?php endif; ?>
        <a href="view_po.php?id=<?= (int)$poId ?>" class="btn btn-link text-decoration-none">Cancel</a>
        <div class="ms-auto help" style="max-width:430px">
          <i class="bi bi-info-circle"></i>
          <b>Post GRN</b> posts only what is filled in and leaves the rest open for the next
          delivery. <b>Post &amp; Close</b> posts and closes the order even if something is short.
        </div>
      </div>
    </div>
  </div>
</form>

<script>
(function () {
  'use strict';

  var form    = document.getElementById('rcvForm');
  var action  = document.getElementById('rcvAction');
  var nowEl   = document.getElementById('postNow');
  var gstEl   = document.getElementById('postGst');
  var dueEl   = document.getElementById('stillDue');

  function recalc() {
    var sub = 0, gst = 0, openLines = 0;

    document.querySelectorAll('.rcv-group').forEach(function (g) {
      var gQty = 0, gAmt = 0;
      g.querySelectorAll('.rcv-row').forEach(function (tr) {
        var q = SL.num(tr.querySelector('.rcv-qty').value);
        var r = SL.num(tr.querySelector('.rcv-rate').value);
        var p = SL.num(tr.querySelector('.rcv-gst').value);
        var t = q * r;
        var x = Math.round(t * p) / 100;
        tr.querySelector('.rcv-amt').textContent = SL.money(t + x);
        gQty += q;
        gAmt += t + x;
        sub  += t;
        gst  += x;
      });

      var bal = parseFloat(g.getAttribute('data-bal-qty')) || 0;
      var qEl = g.querySelector('.rcv-gqty');
      if (!qEl) { return; }                              /* a completed line */
      qEl.textContent = Math.round(gQty * 100) / 100;
      g.querySelector('.rcv-gamt').textContent = SL.money(gAmt);

      var left  = Math.round((bal - gQty) * 100) / 100;
      var state = g.querySelector('.rcv-gstate');
      if (left > 0.005) {
        state.innerHTML = '<span class="badge badge-soft-warning">' + left + ' still due</span>';
        openLines++;
      } else if (left < -0.005) {
        state.innerHTML = '<span class="badge badge-soft-danger">' + (-left) + ' over</span>';
      } else {
        state.innerHTML = '<span class="badge badge-soft-success">line complete</span>';
      }
    });

    nowEl.textContent = SL.money(sub + gst);
    gstEl.textContent = SL.money(gst);
    dueEl.innerHTML = openLines === 0
      ? '<span class="badge badge-soft-success">nothing - PO will close</span>'
      : '<span class="badge badge-soft-warning">' + openLines + ' line(s)</span>';
  }

  document.addEventListener('click', function (e) {
    var add = e.target.closest('.rcv-add');
    if (add) {
      var g    = add.closest('.rcv-group');
      var body = g.querySelector('.rcv-body');
      var row  = body.querySelector('.rcv-row').cloneNode(true);
      row.querySelectorAll('input').forEach(function (i) {
        if (i.classList.contains('rcv-rate') || i.classList.contains('rcv-gst')) { return; }
        if (i.classList.contains('rcv-lot') && i.readOnly) { return; }
        i.value = '';
      });
      row.querySelector('.rcv-qty').value = '';
      body.appendChild(row);
      row.querySelector('.rcv-lot').focus();
      recalc();
      return;
    }

    var del = e.target.closest('.rcv-del');
    if (del) {
      var body2 = del.closest('.rcv-body');
      var rows  = body2.querySelectorAll('.rcv-row');
      if (rows.length === 1) {
        body2.querySelector('.rcv-qty').value = '';
      } else {
        del.closest('.rcv-row').remove();
      }
      recalc();
    }
  });

  form.addEventListener('input', function (e) {
    if (e.target.matches('.rcv-qty, .rcv-rate, .rcv-gst')) { recalc(); }
  });

  function validate() {
    var any = false, problem = null;
    document.querySelectorAll('.rcv-group').forEach(function (g) {
      var hasLot = g.getAttribute('data-has-lot') === '1';
      g.querySelectorAll('.rcv-row').forEach(function (tr) {
        var q = SL.num(tr.querySelector('.rcv-qty').value);
        if (q <= 0) { return; }
        any = true;
        if (hasLot && tr.querySelector('.rcv-lot').value.trim() === '' && !problem) {
          problem = tr.querySelector('.rcv-lot');
        }
      });
    });
    if (problem) {
      alert('Lot number is needed for every quantity you are posting.\n\n'
          + 'If the lot number is not known yet, clear that quantity and receive it on the next GRN.');
      problem.focus();
      return false;
    }
    if (!any) {
      alert('Nothing to post. Enter the quantity received, or use "Close without receiving".');
      return false;
    }
    return true;
  }

  document.getElementById('btnPost').addEventListener('click', function () {
    if (!validate()) { return; }
    action.value = 'post';
    form.submit();
  });

  document.getElementById('btnPostClose').addEventListener('click', function () {
    if (!validate()) { return; }
    if (!confirm('Post this GRN and CLOSE the purchase order?\n\n'
               + 'Any balance quantity will no longer be receivable.')) { return; }
    action.value = 'post_close';
    form.submit();
  });

  var closeBtn = document.getElementById('btnCloseOnly');
  if (closeBtn) {
    closeBtn.addEventListener('click', function () {
      if (!confirm('Close this purchase order without posting anything more?\n\n'
                 + 'Stock already posted stays as it is.')) { return; }
      action.value = 'close_only';
      form.submit();
    });
  }

  recalc();
})();
</script>

<?php require __DIR__ . '/includes/footer.php'; ?>
